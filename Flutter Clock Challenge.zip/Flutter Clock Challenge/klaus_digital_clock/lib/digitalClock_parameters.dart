
import 'package:flutter/material.dart';

Color updatePainterColor;

enum ClockElement{
  canvasBackground,
  painterColor,
  clockBoxDecorationColor,
  themeColor
}

final lightTheme = {
  ClockElement.canvasBackground: Colors.white,
  ClockElement.painterColor: Colors.black87,
  ClockElement.clockBoxDecorationColor: Colors.black87,
  ClockElement.themeColor: Colors.white,
};

final darkTheme = {
  ClockElement.canvasBackground: Colors.black45,
  ClockElement.painterColor: Colors.white70,
  ClockElement.clockBoxDecorationColor: Colors.white70,
  ClockElement.themeColor: Colors.black45,
};