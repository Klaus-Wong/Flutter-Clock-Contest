
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// TODO: It is a drawClockChar func used to draw the user's input Num
Canvas drawClockChar ({
  @required double animationFactor,
  @required Canvas canvas,
  @required double fixHeight, @required double fixWidth,
  @required String drawNum,  @required Color clockCharPainter,
  @required double fromLeft, @required double fromTop, @required double fromRight, @required double fromBottom,
}){

  Color colorBlinkList = clockCharPainter;

  var drawNumContainerWidth = fixWidth /12;
  var drawNumContainerHeight = fixHeight /16;
  var drawPainter = new Paint()
    ..color = colorBlinkList.withOpacity(animationFactor)
    ..style = PaintingStyle.stroke
    ..isAntiAlias = true
    ..strokeCap = StrokeCap.round
    ..strokeWidth = drawNumContainerWidth/3;

  // TODO: Match with the current clockChar return a corresponding pattern
  switch(drawNum){
    // TODO: DrawNum - "0"
    case "0": {

      for(int i = 0; i <= 1; i++){
        for(int j = 3; j <= 3; j++){
          for(int k = 3 - (i * 2); k <= 8; k++){
            if (i == 1 && (3 <= k  && k <= 6)){
              continue;
            }
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 2 * k + 1))/2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2)),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 0; i < 2; i++){
        for(int j = 5; j <= 10; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 3)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 8; i <10; i++){
        for(int j = 5; j<=10; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 3)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=1;i++){
        for(int j=11; j<=11;j++){
          for(int k =2 + i; k<=9 - i;k++){
            if (i ==0 && (3 <k  && k<8)){
              continue;}
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

    }
    break;

  // TODO: DrawNum - "1"
    case "1":

      for(int i = 7; i <9; i++){
        for(int j = 3; j<=12; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 1)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=4;i++){
        for(int j=3; j<=3;j++){
          for(int k =6; k<=7;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }
    break;

  // TODO: DrawNum - "2"
    case "2": {

      for(int i = 0; i<=1;i++){
        for(int j=3; j<=3;j++){
          for(int k =3 - (i * 2); k<=8;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 0; i<=1;i++){
        canvas.drawRect(new Rect.fromCenter(
          center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 3)) /2),  (drawNumContainerHeight * (11)/2) ),
          height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
      }

      for(int i = 0; i<=5;i++){
        for(int j=5; j<=5;j++){
          for(int k =8; k<=9;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 0; i<=1;i++){
        for(int j=11; j<=11;j++){
          for(int k =2 -i; k<=10;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }
    }
    break;

  // TODO: DrawNum - "3"
    case "3": {

      for(int i = 0; i<=1;i++){
        for(int j=3; j<=3;j++){
          for(int k =3 - (i * 2); k<=8;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 0; i<=1;i++){
        canvas.drawRect(new Rect.fromCenter(
          center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 3)) /2),  (drawNumContainerHeight * (11)/2) ),
          height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
      }

      for(int i = 0; i<=1;i++){
        for(int j=5; j<=5;j++){
          for(int k =8; k<=9 + 1 - i;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i=7; i<=8;i++){
        for(int j =5; j<=10;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=1;i++){
        canvas.drawRect(new Rect.fromCenter(
          center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 3)) /2),  (drawNumContainerHeight * (21)/2) ),
          height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
      }

      for(int i = 0; i<=1;i++){
        for(int j=9; j<=9;j++){
          for(int k =9 - i; k<=10;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 0; i<=1;i++){
        for(int j=11; j<=11;j++){
          for(int k =2 + (i * 2); k<=9;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }
    }
    break;

  // TODO: DrawNum - "4"
    case "4": {

      for(int i = 1; i <3; i++){
        for(int j = 3; j<=7; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 1)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 9; i <11; i++){
        for(int j = 3; j<=7; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 1)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=0;i++){
        for(int j = 1;j<=10; j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 17)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 9; i <11; i++){
        for(int j = 9; j<=12; j++) {
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 1)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }
    }
    break;

  // TODO: DrawNum - "5"
    case "5": {

      for(int i = 0; i<=1;i++){
        for(int j=3; j<=3;j++){
          for(int k =2; k<=10;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i = 1; i<=2; i++){
        for(int j =5;j<=6;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 1)) /2),  (drawNumContainerHeight * (2 * j + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 7; i<=8;i++){
        for(int j = 1;j<=1+i; j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i= 1; i<=2; i++){
        for(int j=8;j<=10;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 17)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=11; i<=11;i++){
        for(int j =2; j<=9;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=12; i<=12;i++){
        for(int j =1; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }
    }
    break;

  // TODO: DrawNum - "6"
    case "6": {

      for(int i = 0; i<=4;i++){
        for(int j=3; j<=3;j++){
          for(int k =8; k<=9;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }

      for(int i=8; i<=8;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=1;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 19)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=0;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 23)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=12; i<=12;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }
    }
    break;

  // TODO: DrawNum - "7"
    case "7": {

      for(int i = 0; i<=1;i++){
        for(int j = 1;j<=9; j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * i + 2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 7)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=7;i++){
        for(int j=5; j<=5;j++){
          for(int k =8; k<=9;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2 * k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }
    }
    break;

  // TODO: DrawNum - "8"
    case "8": {

      for(int i=3; i<=3;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=1;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 9)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=0;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }

          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 13)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=7; i<=7;i++){
        for(int j =3; j<=8;j++){

          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=8; i<=8;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=1;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 19)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=0;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 23)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=12; i<=12;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }
    }
    break;

  // TODO: DrawNum - "9"
    case "9": {

      for(int i=3; i<=3;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * ((j) + (1 + j))) /2),  (drawNumContainerHeight * ((i) + (1 + i))/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=1;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 9)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=0; i<=0;i++){
        for(int j =2 - i; j<=9 + i;j++){
          if (j>2 - i && j <=8+i){
            continue;
          }
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 13)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i=7; i<=7;i++){
        for(int j =3; j<=8;j++){
          canvas.drawRect(new Rect.fromCenter(
            center: new Offset(((2 * fromLeft + drawNumContainerWidth * (2 * j + 1)) /2),  (drawNumContainerHeight * (2 * i + 1)/2) ),
            height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
        }
      }

      for(int i = 0; i<=4;i++){
        for(int j=8; j<=8;j++){
          for(int k =6; k<=7;k++){
            canvas.drawRect(new Rect.fromCenter(
              center: new Offset(((2 * fromLeft + drawNumContainerWidth * (-2 * i + 2* k + 1)) /2),  (drawNumContainerHeight * (2 * i + 2 * j + 1)/2) ),
              height: drawNumContainerHeight * animationFactor, width: drawNumContainerWidth * animationFactor,), drawPainter);
          }
        }
      }
    }
    break;
  }
  return canvas;
}