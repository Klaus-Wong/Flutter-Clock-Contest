
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:klaus_digital_clock/drawNumCanvas.dart';

class DigitalClockPainter extends CustomPainter{
  final List<String> clockCharList; // clockCharList = [hour_firstChar, hour_secChar, min_firstChar, min_secChar]
  final Color clockCharPainter;
  double animationFactor;
  Paint clockMiddlePoint;

  DigitalClockPainter({@required this.animationFactor, @required this.clockCharList, @required this.clockCharPainter});

  @override
  void paint(Canvas canvas, Size size) {
    var numContainerWidth = size.width/6;
    clockMiddlePoint = Paint()
      ..color = clockCharPainter
      ..strokeCap = StrokeCap.round
      ..strokeWidth=5;

    // TODO: To draw the Clock Char
    /// Draw the first Clock Char - hour_firstChar
    drawClockChar(canvas: canvas,fixHeight: size.height, fixWidth: numContainerWidth,  drawNum: clockCharList[0], fromLeft: (size.width/6 - numContainerWidth * 1/4),
        fromTop: 0, fromRight: size.width/6 + numContainerWidth * 1/4 + numContainerWidth, fromBottom: size.height, clockCharPainter: clockCharPainter, animationFactor: animationFactor);

    /// Draw the second Clock Char - hour_secChar
    drawClockChar(canvas: canvas,fixHeight: size.height, fixWidth: numContainerWidth,  drawNum: clockCharList[1], fromLeft: ((size.width/6) * 2  - numContainerWidth * 1/4),
        fromTop: 0, fromRight: ((size.width/6) * 2 + numContainerWidth * 1/4 + numContainerWidth), fromBottom: size.height, clockCharPainter: clockCharPainter, animationFactor: animationFactor);


    /// Draw the third Clock Char - min_firstChar
    drawClockChar(canvas: canvas,fixHeight: size.height, fixWidth: numContainerWidth,  drawNum: clockCharList[2], fromLeft: ((size.width/6) * 4  - numContainerWidth * 3/4),
        fromTop: 0, fromRight: ((size.width/6) * 4 + numContainerWidth * 1/4), fromBottom: size.height, clockCharPainter: clockCharPainter, animationFactor: animationFactor);

    /// Draw the fourth Clock Char - min_secChar
    drawClockChar(canvas: canvas,fixHeight: size.height, fixWidth: numContainerWidth, drawNum: clockCharList[3], fromLeft: ((size.width/6) * 5  - numContainerWidth *(3/4)),
        fromTop: 0, fromRight: ((size.width/6) * 5 + numContainerWidth * 1/4), fromBottom: size.height, clockCharPainter: clockCharPainter, animationFactor: animationFactor);

    // TODO: Draw the Circle to separate the hour & min
    canvas.drawCircle(new Offset(size.width/2, size.height * 2.0/5), size.height/25, clockMiddlePoint);
    canvas.drawCircle(new Offset(size.width/2, size.height * 3.0/5), size.height/25, clockMiddlePoint);
  }

  @override
  bool shouldRepaint(DigitalClockPainter oldDelegate) {
    // TODO: implement shouldRepaint
    return oldDelegate.animationFactor != animationFactor;
  }
}