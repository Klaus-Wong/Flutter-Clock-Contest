

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_clock_helper/model.dart';
import 'package:klaus_digital_clock/digitalClockPainter.dart';
import 'package:intl/intl.dart';
import 'digitalClock_parameters.dart';


class DigitalClock extends StatefulWidget{
  const DigitalClock({@required this.model, Key key}) : super (key: key);
  final ClockModel model;
  @override
  _DigitalClockState createState() => _DigitalClockState();
}

class _DigitalClockState extends State<DigitalClock> with SingleTickerProviderStateMixin{

  var _temperature = '';
  var _temperatureRange = '';
  var _condition = '';
  var _location = '';
  double _animationFactor = 0;
  DateTime _dateTime = DateTime.now();
  Timer _timer;
  Animation<double> _animationValue;
  AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    _updateTime();
    _updateModel();
    /// Init AnimationController
    _animationController = AnimationController(
        duration:  const Duration(seconds: 5), vsync: this);
    _animationValue=Tween(begin: 0.0,end: 1.0).animate(_animationController)
      ..addStatusListener((status){
        if(status == AnimationStatus.completed){
          _animationController.reverse();
        }else if (status == AnimationStatus.dismissed){
          _animationController.forward();
        }})
//      ..addStatusListener((state) => print('$state'))
      ..addListener((){
        setState(() {
          _animationFactor = _animationValue.value;
        });
      });
    _animationController.forward();
  }

  @override
  void didUpdateWidget(DigitalClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    widget.model.dispose();
    /// Dispose AnimationController
    _animationController.dispose();
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      _temperature = widget.model.temperatureString;
      _temperatureRange = '(${widget.model.low} - ${widget.model.highString})';
      _condition = widget.model.weatherString;
      _location = widget.model.location;
    });
  }

  void _updateTime() async{
    setState(() {
      _dateTime = DateTime.now();
//      print(_dateTime);
      // Update once per minute. If you want to update every second, use the
      // following code.
//      _timer = Timer(
//        Duration(minutes: 1) -
//            Duration(seconds: _dateTime.second) -
//            Duration(milliseconds: _dateTime.millisecond),
//        _updateTime,
//      );
      // Update once per second, but make sure to do it at the beginning of each
      // new second, so that the clock is accurate.
       _timer = Timer(
         Duration(seconds: 1) - Duration(milliseconds: _dateTime.millisecond),
         _updateTime,
       );
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).brightness == Brightness.light
        ? lightTheme
        : darkTheme;
    final hour =
    DateFormat(widget.model.is24HourFormat ? 'HH' : 'hh').format(_dateTime);
    final minute = DateFormat('mm').format(_dateTime);
    // TODO: implement buildreturn SafeArea(
      return Scaffold(
        body: Center(
          child: Container(
            decoration: BoxDecoration(
              color: colors[ClockElement.clockBoxDecorationColor],
              border: Border.all(
                color: colors[ClockElement.clockBoxDecorationColor],
                width: 15,
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            // TODO: To full fill the first requirement -> UI Design Landscape Layout with 5.3 aspect ratio
            /// Height / Width = 3/5
            height: (MediaQuery.of(context).size.width * (3/5)) ,
            child: Column(
              children: <Widget>[
                Expanded(
                  flex: 2,
                  child: Container(
                    color: colors[ClockElement.themeColor],
                    alignment: Alignment.center,
                    child: Text(_location,  style: TextStyle(color: colors[ClockElement.painterColor]),),
                  ),
                ),
                Expanded(
                  flex: 8,
                  child: Container(
                    child: CustomPaint(
                      size: Size(MediaQuery.of(context).size.width, MediaQuery.of(context).size.height),
                      isComplex: true,
                      foregroundPainter:
                      // TODO: A DigitalClockPainter used to draw a SmartClock Number Pattern
                      DigitalClockPainter(
                        clockCharList: [hour[0], hour[1],minute[0],minute[1]], // Get back each string of the hour & minute
                        animationFactor: _animationFactor, // AnimationFactor used to controller the scale of the drawing number pattern
                        clockCharPainter: colors[ClockElement.painterColor],  // Painter as a drawing pen of the canvas
                      ),
                      child:  Column(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                      flex: 2,
                                      child: Container(
                                        padding: EdgeInsets.only(left: 10),
                                        child: Text(_condition, textAlign: TextAlign.start,style: TextStyle(color: colors[ClockElement.painterColor]),),
                                      )
                                  ),
                                  Expanded(
                                      flex: 3,
                                      child: Container(
                                        color: Colors.transparent,
                                      )),
                                  Expanded(
                                      flex: 6,
                                      child: Container(
                                        padding: EdgeInsets.only(right: 10),
                                        child: Text("$_temperature   $_temperatureRange", textAlign: TextAlign.end,style: TextStyle(color: colors[ClockElement.painterColor], ),),
                                      )
                                  ),
                                ],
                              )),
                          Expanded(
                              flex: 4,
                              child: Container(
                                color: Colors.transparent,
                              )),
                          Expanded(
                              flex: 1,
                              child: Container(
                                color: Colors.transparent,
                              )),
                        ],
                      ),
                    ),
                    color: colors[ClockElement.canvasBackground],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }
}